# Jarvis Trading Bot

Bu bot, CoinMarketCap verilerini kullanarak belirli coin'lerdeki fiyat ve hacim değişimlerine göre sinyal üretir.
