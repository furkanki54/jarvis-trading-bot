import time
print("Jarvis bot çalışıyor...")
while True:
    time.sleep(60)
